﻿WTTDP Journal Mod Release

Contents:
- BepInEx\plugins\WTTDP.JournalMod.dll

Install:
1. Make sure BepInEx is already installed for Welcome To The Dark Place.
2. Copy the BepInEx folder from this package into the game folder.
3. Allow the plugins folder to merge.
