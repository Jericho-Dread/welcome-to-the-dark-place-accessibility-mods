﻿Dark-Place_Journal

Contents:
- BepInEx\plugins\Dark-Place_Journal.dll

Requirements:
- BepInEx 5.4.23.5 must already be installed for Welcome To The Dark Place.

Install:
1. Copy the BepInEx folder from this package into the game folder.
2. If you previously used WTTDP.JournalMod.dll, remove the old DLL to avoid duplicate plugin loading.
3. Allow the plugins folder to merge.
