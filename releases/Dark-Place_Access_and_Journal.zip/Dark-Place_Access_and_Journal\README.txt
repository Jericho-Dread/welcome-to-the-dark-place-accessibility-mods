﻿Dark-Place Accessibility and Journal Mods

This package includes:
- BepInEx 5.4.23.5
- Dark-Place_Access.dll
- Dark-Place_Journal.dll
- nvdaControllerClient32.dll
- nvdaControllerClient64.dll

Install:
1. Copy everything in this folder into your Welcome To The Dark Place game folder.
2. Allow files to merge or overwrite if prompted.
3. If you already installed older WTTDP or Dark-Place plugin DLLs manually, remove duplicate old copies from BepInEx\plugins.
4. Launch the game with NVDA running.
