﻿Dark-Place_Access

Contents:
- BepInEx\plugins\Dark-Place_Access.dll
- nvdaControllerClient32.dll
- nvdaControllerClient64.dll

Requirements:
- BepInEx 5.4.23.5 must already be installed for Welcome To The Dark Place.

Install:
1. Copy the BepInEx folder from this package into the game folder.
2. Copy both nvdaControllerClient DLLs into the game folder beside the game EXE.
3. If you previously used WTTDP.AccessibilityMod.dll, remove the old DLL to avoid duplicate plugin loading.
4. Launch the game with NVDA running.
