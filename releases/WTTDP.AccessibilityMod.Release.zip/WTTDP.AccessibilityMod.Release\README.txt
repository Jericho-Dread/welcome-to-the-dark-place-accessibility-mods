﻿Welcome To The Dark Place Accessibility Mod Release

Contents:
- BepInEx\plugins\WTTDP.AccessibilityMod.dll
- nvdaControllerClient32.dll
- nvdaControllerClient64.dll

Requirements:
- BepInEx must already be installed for Welcome To The Dark Place.

Install:
1. Copy the BepInEx folder from this package into the game folder.
2. Copy both nvdaControllerClient DLLs into the game folder beside the game EXE.
3. Launch the game with NVDA running.
